package com.example.lab1b;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtMedicine, edtDate;
    TextView txtMedicine;
    Spinner spn;
    Switch swtch;
    Button btnInsert, btnFetch;
    DbConnection dbConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbConnection = new DbConnection(this);

        txtMedicine=findViewById(R.id.txtMedicine);
        edtMedicine = findViewById(R.id.edtMedicine);
        edtDate=findViewById(R.id.edtDate);
        spn=findViewById(R.id.spinner);
        swtch=findViewById(R.id.switch2);
        btnInsert=findViewById(R.id.btnInsert);
        btnFetch=findViewById(R.id.btnFetch);

        swtch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(!isChecked){
                    btnFetch.setVisibility(View.INVISIBLE);
                    txtMedicine.setVisibility(View.VISIBLE);
                    edtMedicine.setVisibility(View.VISIBLE);
                    btnInsert.setVisibility(View.VISIBLE);
                }
                else{
                    btnFetch.setVisibility(View.VISIBLE);
                    txtMedicine.setVisibility(View.INVISIBLE);
                    edtMedicine.setVisibility(View.INVISIBLE);
                    btnInsert.setVisibility(View.INVISIBLE);
                }
            }
        });
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = edtMedicine.getText().toString();
                String date = edtDate.getText().toString();
                String time = spn.getSelectedItem().toString();

                boolean insert = dbConnection.insertValues(name,date,time);

                if(insert==true){
                    Toast.makeText(MainActivity.this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show();
                    edtMedicine.setText(null);
                    edtDate.setText(null);
                }
                else{
                    Toast.makeText(MainActivity.this, "Data Insertion Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = edtDate.getText().toString();
                String time = spn.getSelectedItem().toString();
                String med="";

                Cursor cursor = dbConnection.RetrieveData(date,time);
                cursor.moveToFirst();

                do {
                    med += String.valueOf(cursor.getString(cursor.getColumnIndex("medicineName")));
                    med += "\n";
                } while (cursor.moveToNext());

                Toast.makeText(MainActivity.this, med, Toast.LENGTH_LONG).show();
            }
        });
    }


}